import React from 'react'
import ReactDOM from 'react-dom/client'
import App from './App'
import './index.css'

if (new URLSearchParams(location.search).has('mobile')) document.documentElement.classList.add('mobile-preview')

ReactDOM.createRoot(document.getElementById('root')!).render(<React.StrictMode><App /></React.StrictMode>)
