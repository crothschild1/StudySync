import { useState, useEffect } from "react"
import type { Profile } from "./App"

type IconName = string

export function Icon({ name, size = 20 }: { name: IconName; size?: number }) {
  const paths: Record<IconName, React.ReactNode> = {
    university: <><path d="m3 8 9-5 9 5-9 5zM3 21h18M6 11v7M12 13v5M18 11v7"/></>,
    building: <><rect x="5" y="3" width="14" height="18" rx="2"/><path d="M9 7h1m4 0h1M9 11h1m4 0h1M10 21v-6h4v6"/></>,
    sun: <><circle cx="12" cy="12" r="4"/><path d="M12 2v2m0 16v2M2 12h2m16 0h2M5 5l1.5 1.5m11 11L19 19M5 19l1.5-1.5m11-11L19 5"/></>,
    moon: <path d="M21 13A9 9 0 0 1 11 3a9 9 0 1 0 10 10Z"/>,
    cards: <><rect x="7" y="4" width="13" height="16" rx="2"/><path d="M4 17H3V4a2 2 0 0 1 2-2h10M11 9h5m-5 4h4"/></>,
    play: <><rect x="3" y="4" width="18" height="16" rx="3"/><path d="m10 8 6 4-6 4z"/></>,
    mic: <><rect x="9" y="3" width="6" height="12" rx="3"/><path d="M5 10v2a7 7 0 0 0 14 0v-2M12 19v3m-4 0h8"/></>,
    target: <><circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1"/></>,
    users: <><circle cx="9" cy="8" r="3"/><path d="M3 21v-2a6 6 0 0 1 12 0v2M16 5a3 3 0 0 1 0 6m3 10v-2a6 6 0 0 0-2-4"/></>,
    home: <><path d="m3 10 9-7 9 7"/><path d="M5 9v11h14V9M9 20v-6h6v6"/></>,
    calendar: <><rect x="3" y="5" width="18" height="16" rx="2"/><path d="M16 3v4M8 3v4M3 10h18"/></>,
    book: <><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20V4H6.5A2.5 2.5 0 0 0 4 6.5z"/><path d="M4 6.5v13"/></>,
    user: <><circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/></>,
    check: <path d="m5 12 4 4L19 6"/>,
    clock: <><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></>,
    flame: <path d="M12 22c4 0 7-3 7-7 0-3-2-6-5-9 0 3-2 4-3 5 0-3-1-6-3-8 0 5-3 7-3 12 0 4 3 7 7 7Z"/>,
    plus: <path d="M12 5v14M5 12h14"/>,
    arrow: <path d="m9 18 6-6-6-6"/>,
    spark: <path d="m12 3 1.5 4.5L18 9l-4.5 1.5L12 15l-1.5-4.5L6 9l4.5-1.5ZM18.5 15l.8 2.2 2.2.8-2.2.8-.8 2.2-.8-2.2-2.2-.8 2.2-.8Z"/>,
  }
  return <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">{paths[name]}</svg>
}

const initialTasks = [
  { id: 1, time: "09:00", duration: "45 Min.", subject: "Statistik", title: "Hypothesentests wiederholen", color: "purple", done: true },
  { id: 2, time: "11:30", duration: "60 Min.", subject: "Mikroökonomie", title: "Kapitel 6: Marktformen", color: "orange", done: false },
  { id: 3, time: "16:00", duration: "40 Min.", subject: "Marketing", title: "Karteikarten: Markenführung", color: "teal", done: false },
]

const exams = [
  { day: "18", month: "JUN", subject: "Statistik", detail: "Klausur · schwer", color: "purple", progress: 68 },
  { day: "25", month: "JUN", subject: "Mikroökonomie", detail: "Klausur · mittel", color: "orange", progress: 42 },
  { day: "02", month: "JUL", subject: "Marketing", detail: "Hausarbeit · mittel", color: "teal", progress: 31 },
]

export default function Dashboard({onOnboarding,profile}:{onOnboarding:()=>void;profile:Profile}) {
  const [tab, setTab] = useState("Heute")
  const [tasks, setTasks] = useState(() => {try{return JSON.parse(localStorage.getItem("studysync-tasks")||"null") || initialTasks}catch{return initialTasks}}) as [typeof initialTasks, React.Dispatch<React.SetStateAction<typeof initialTasks>>]
  const [dialog,setDialog] = useState("")
  const [customSubjects,setCustomSubjects] = useState<typeof exams>([])
  useEffect(()=>{localStorage.setItem("studysync-tasks",JSON.stringify(tasks))},[tasks])
  const [toast, setToast] = useState("")
  const [proOpen, setProOpen] = useState(false)

  const totalMinutes=tasks.reduce((sum,t)=>sum+parseInt(t.duration),0)
  const toggleTask = (id: number) => setTasks(tasks.map(t => t.id === id ? { ...t, done: !t.done } : t))
  const showToast = (message: string) => {
    setToast(message)
    window.setTimeout(() => setToast(""), 2200)
  }

  return (
    <main className="app-shell">
      <div className="phone">
        <header className={`topbar ${tab !== "Heute" ? "compact" : "today"}`}>
          <div>
            <p className="eyebrow">{tab === "Heute" ? "DIENSTAG, 11. JUNI" : tab === "Plan" ? "11.–17. JUNI" : tab === "Fächer" ? "3 AKTIVE FÄCHER" : "DEIN BEREICH"}</p>
            <h1>{tab === "Heute" ? "Guten Morgen, Lea" : tab === "Plan" ? "Dein Lernplan" : tab === "Fächer" ? "Meine Fächer" : "Dein Profil"}</h1>
          </div>
          <button className="avatar" aria-label="Profil öffnen" onClick={() => setTab("Profil")}>LS</button>
        </header>

        <div className="content">
          {tab === "Heute" && <>
            <section className="focus-card">
              <div className="focus-top">
                <div className="streak-icon"><Icon name="flame" size={22}/></div>
                <div><strong>7 Tage im Flow</strong><span>Dein längster Streak: 12 Tage</span></div>
                <button className="share" onClick={() => {const text="7 Tage im Flow – mein Lernerfolg mit StudySync!"; if(navigator.clipboard) navigator.clipboard.writeText(text).then(()=>showToast("Erfolg in die Zwischenablage kopiert"),()=>showToast(text)); else showToast(text)}}>Teilen</button>
              </div>
              <div className="daily-goal">
                <div><span>DEIN TAGESZIEL</span><strong>{tasks.filter(t => t.done).length} von {tasks.length} Einheiten geschafft</strong></div>
                <div className="goal-track"><i style={{width: `${tasks.filter(t => t.done).length / tasks.length * 100}%`}}></i></div>
              </div>
              <div className="week-dots">
                {["M","D","M","D","F","S","S"].map((d,i) => <div key={i} className="day"><span className={i < 4 ? "dot active" : "dot"}>{i < 4 && <Icon name="check" size={13}/>}</span><small>{d}</small></div>)}
              </div>
            </section>

            <section className="section">
              <div className="section-head">
                <div><p className="eyebrow">DEIN TAG</p><h2>Heute geplant</h2></div>
                <span className="total time-pill"><Icon name="clock" size={15}/> {Math.floor(totalMinutes/60)} Std. {totalMinutes%60} Min.</span>
              </div>
              <div className="task-list">
                {tasks.map(task => (
                  <article className={`task ${task.color} ${task.done ? "completed" : ""}`} key={task.id}>
                    <div className="task-time"><strong>{task.time}</strong><span>{task.duration}</span></div>
                    <div className={`subject-line ${task.color}`}></div>
                    <div className="task-copy"><span className={`subject ${task.color}`}>{task.subject}</span><h3>{task.title}</h3></div>
                    <button className="check-button" aria-label={`${task.title} ${task.done ? "als offen markieren" : "abschließen"}`} onClick={() => toggleTask(task.id)}>{task.done && <Icon name="check" size={17}/>}</button>
                  </article>
                ))}
              </div>
              <button className="add-button" onClick={() => setDialog("Lerneinheit hinzufügen")}><Icon name="plus" size={19}/> Lerneinheit hinzufügen</button>
            </section>

            <section className="pro-card">
              <div className="pro-icon"><Icon name="spark" size={23}/></div>
              <div><span className="pro-label">PRO-VORSCHAU</span><h3>Plan automatisch anpassen</h3><p>Ein Termin ist ausgefallen? Lass deinen Lernplan einmal kostenlos neu planen.</p></div>
              <button onClick={() => setProOpen(true)}>Jetzt testen <Icon name="arrow" size={16}/></button>
            </section>

            <section className="section exams">
              <div className="section-head"><div><p className="eyebrow">IM BLICK</p><h2>Nächste Termine</h2></div><button className="text-button" onClick={() => setTab("Fächer")}>Alle ansehen</button></div>
              {exams.slice(0,2).map(exam => (
                <article className="exam" key={exam.subject}>
                  <div className={`date-box ${exam.color}`}><strong>{exam.day}</strong><span>{exam.month}</span></div>
                  <div className="exam-copy"><h3>{exam.subject}</h3><p>{exam.detail}</p><div className="progress"><i className={exam.color} style={{width: `${exam.progress}%`}}></i></div></div>
                  <strong className="percent">{exam.progress}%</strong>
                </article>
              ))}
            </section>
          </>}

          {tab === "Plan" && <PlanView tasks={tasks} toggleTask={toggleTask} onAdd={()=>setDialog("Lerneinheit hinzufügen")}/>}
          {tab === "Fächer" && <SubjectsView customSubjects={customSubjects} onAction={setDialog}/>}
          {tab === "Profil" && <ProfileView onOnboarding={onOnboarding} profile={profile}/>}
        </div>

        <nav className="bottom-nav" aria-label="Hauptnavigation">
          {[["Heute","home"],["Plan","calendar"],["Fächer","book"],["Profil","user"]].map(([label,icon]) => (
            <button key={label} className={tab === label ? "active" : ""} onClick={() => setTab(label)}><Icon name={icon as IconName}/><span>{label}</span></button>
          ))}
        </nav>
        {proOpen && <ProPreview onClose={() => setProOpen(false)} onApplied={() => { setTasks(ts=>ts.map(t=>t.id===1?{...t,time:"Morgen 09:00",done:false}:t.id===2?{...t,duration:"35 Min."}:t)); setProOpen(false); showToast("Dein neuer Lernplan ist aktiv") }}/>}
        {dialog && <EntryDialog title={dialog} onClose={()=>setDialog("")} onSubmit={(data)=>{if(dialog==="Neues Fach hinzufügen"){setCustomSubjects(s=>[...s,{subject:data.subject,day:data.date.slice(8),month:new Date(data.date+"T12:00:00").toLocaleDateString("de-AT",{month:"short"}).toUpperCase(),detail:"Klausur · "+data.difficulty,color:"teal",progress:0}])}else{setTasks(s=>[...s,{id:Date.now(),subject:data.subject,title:data.title,time:data.time,duration:data.duration+" Min.",color:"teal",done:false}])};setDialog("");showToast("Gespeichert")}}/>}
        {toast && <div className="toast"><Icon name="check" size={17}/>{toast}</div>}
      </div>
    </main>
  )
}

function ProPreview({onClose, onApplied}: {onClose:()=>void; onApplied:()=>void}) {
  const [step, setStep] = useState<"overview"|"plan">("overview")
  if (step === "overview") return <div className="pro-overlay">
    <div className="pro-sheet">
      <div className="sheet-handle"></div>
      <div className="pro-sheet-head">
        <button className="close-button" onClick={onClose} aria-label="Schließen">×</button>
        <div className="pro-logo"><Icon name="spark" size={24}/></div>
        <span>STUDYSYNC PRO</span>
        <h2>Dein Plan denkt mit.</h2>
        <p>Automatisch neu planen, Engpässe früh erkennen und immer wissen, was als Nächstes zählt.</p>
        <div className="pro-price"><strong>3,99 €</strong><span>pro Monat · jederzeit kündbar</span></div>
      </div>
      <div className="feature-list">
        <article><div className="feature-icon lavender"><Icon name="spark"/></div><div><h3>Automatische Neuplanung</h3><p>Verpasste Einheiten landen intelligent in deinen nächsten freien Zeitfenstern.</p></div></article>
        <article><div className="feature-icon peach"><Icon name="flame"/></div><div><h3>Dynamische Prioritäten</h3><p>Termine, Schwierigkeit und Restaufwand aller Prüfungen werden gemeinsam bewertet.</p></div></article>
        <article><div className="feature-icon mint"><Icon name="clock"/></div><div><h3>Lernt aus deinem Fortschritt</h3><p>Der Plan passt sich an deine tatsächliche Lerndauer und deinen Fortschritt an.</p></div></article>
        <article><div className="feature-icon yellow"><Icon name="check"/></div><div><h3>Analysen & Empfehlungen</h3><p>Vergleiche Soll und Ist und erhalte konkrete, nachvollziehbare nächste Schritte.</p></div></article>
      </div>
      <div className="sheet-actions">
        <button className="pro-primary" onClick={()=>setStep("plan")}><Icon name="spark" size={18}/> Kostenlose Neuplanung testen</button>
        <button className="pro-secondary" onClick={onClose}>Vielleicht später</button>
      </div>
    </div>
  </div>

  return <div className="pro-overlay">
    <div className="pro-sheet planner-sheet">
      <div className="sheet-handle"></div>
      <div className="planner-head">
        <button className="close-button" onClick={()=>setStep("overview")} aria-label="Zurück">‹</button>
        <div><span>PRO-NEUPLANUNG</span><h2>Dein optimierter Plan</h2></div>
        <div className="pro-mini"><Icon name="spark" size={17}/></div>
      </div>
      <div className="capacity-alert">
        <div className="alert-icon">!</div>
        <div><strong>Zeitengpass erkannt</strong><p>Bis zur Statistik-Klausur fehlen dir etwa 1 Std. 20 Min. Lernzeit.</p></div>
      </div>
      <section className="recommendation">
        <div className="recommend-label"><Icon name="spark" size={15}/> EMPFEHLUNG</div>
        <h3>Statistik hat jetzt Vorrang</h3>
        <p>Die Prüfung ist bereits in 7 Tagen und der verbleibende Aufwand ist höher als bei deinen anderen Fächern.</p>
        <div className="priority-row"><span className="purple">1 · Statistik</span><span className="orange">2 · Mikroökonomie</span><span className="teal">3 · Marketing</span></div>
      </section>
      <section className="changes">
        <div className="pro-section-title"><div><span>PLANÄNDERUNGEN</span><h3>3 Einheiten angepasst</h3></div><span className="change-badge">+ 80 Min.</span></div>
        <article><div className="change-date purple"><strong>12</strong><span>JUN</span></div><div><span>VERSCHOBEN</span><h3>Hypothesentests</h3><p>Von heute auf morgen, weil die Statistik-Prüfung früher stattfindet.</p></div></article>
        <article><div className="change-date orange"><strong>13</strong><span>JUN</span></div><div><span>VERKÜRZT</span><h3>Marktformen</h3><p>Auf 35 Min. angepasst, da du zuletzt schneller als geplant warst.</p></div></article>
        <article><div className="change-date teal"><strong>14</strong><span>JUN</span></div><div><span>NEU EINGEPLANT</span><h3>Probeklausur Statistik</h3><p>Freies Zeitfenster am Freitag optimal genutzt.</p></div></article>
      </section>
      <section className="analysis-card">
        <div className="pro-section-title"><div><span>FORTSCHRITTSANALYSE</span><h3>Diese Woche</h3></div><span className="analysis-detail-label">Soll / Ist</span></div>
        <div className="analysis-row"><span>Statistik</span><div><i className="planned" style={{width:"88%"}}></i><i className="actual purple" style={{width:"72%"}}></i></div><strong>3:10 h</strong></div>
        <div className="analysis-row"><span>Mikroökonomie</span><div><i className="planned" style={{width:"70%"}}></i><i className="actual orange" style={{width:"54%"}}></i></div><strong>2:20 h</strong></div>
        <div className="analysis-legend"><span><i></i>Geplant</span><span><i></i>Tatsächlich</span></div>
      </section>
      <div className="apply-bar"><div><span>NEUER PLAN</span><strong>8 Std. 30 Min. · 9 Einheiten</strong></div><button onClick={onApplied}>Plan anwenden</button></div>
    </div>
  </div>
}

function PlanView({tasks, toggleTask,onAdd}: {tasks: typeof initialTasks; toggleTask: (id:number)=>void;onAdd:()=>void}) {
  const [day, setDay] = useState(1)
  const days = [["Mo","10"],["Di","11"],["Mi","12"],["Do","13"],["Fr","14"],["Sa","15"]]
  const dayPlans = [
    [{time:"10:00", title:"Deskriptive Statistik", subject:"Statistik", color:"purple", length:"50 Min."},{time:"14:30", title:"Kapitel 5 zusammenfassen", subject:"Mikroökonomie", color:"orange", length:"45 Min."}],
    tasks.map(t => ({time:t.time,title:t.title,subject:t.subject,color:t.color,length:t.duration,id:t.id,done:t.done})),
    [{time:"09:30", title:"Übungsblatt 8", subject:"Statistik", color:"purple", length:"60 Min."},{time:"17:00", title:"Gliederung überarbeiten", subject:"Marketing", color:"teal", length:"40 Min."}],
    [{time:"11:00", title:"Marktformen: Aufgaben", subject:"Mikroökonomie", color:"orange", length:"55 Min."}],
    [{time:"09:00", title:"Probeklausur", subject:"Statistik", color:"purple", length:"90 Min."},{time:"15:00", title:"Literatur einarbeiten", subject:"Marketing", color:"teal", length:"45 Min."}],
    [],
  ]
  const active = dayPlans[day]
  return <section className="subpage plan-page">
    <div className="plan-summary">
      <div className="ring"><strong>72%</strong><span>geschafft</span></div>
      <div><span className="summary-label">WOCHENZIEL</span><h2>6 Std. 10 Min.</h2><p>von 8 Std. 30 Min. geplant</p></div>
      <div className="mini-bars">{[70,100,45,80,32].map((height,i)=><i key={i} style={{height:`${height}%`}}></i>)}</div>
    </div>
    <div className="calendar-strip">{days.map((d,i)=><button className={i===day?"selected":""} key={d[0]} onClick={()=>setDay(i)}><span>{d[0]}</span><strong>{d[1]}</strong><i className={dayPlans[i].length ? "has-plan" : ""}></i></button>)}</div>
    <div className="day-title"><div><p className="eyebrow">{day === 5 ? "GEPLANTER RUHETAG" : `${active.length} LERNEINHEITEN`}</p><h2>{["Montag","Heute, Dienstag","Mittwoch","Donnerstag","Freitag","Samstag"][day]}</h2></div><button aria-label="Lerneinheit hinzufügen" onClick={onAdd}><Icon name="plus" size={19}/></button></div>
    {active.length > 0 ? <div className="timeline">{active.map((task:any,i)=><article className={`timeline-task ${task.color} ${task.done?"completed":""}`} key={task.title}><div className="timeline-time"><strong>{task.time}</strong><span>{task.length}</span></div><div className="timeline-dot"></div><div className="timeline-card"><span>{task.subject}</span><h3>{task.title}</h3><p>{i === 0 ? "Fokusblock" : "Wiederholen & festigen"}</p></div>{task.id && <button className="check-button" onClick={()=>toggleTask(task.id)}>{task.done&&<Icon name="check" size={17}/>}</button>}</article>)}</div> : <div className="rest-card"><div className="rest-illustration"><span></span><i></i></div><h3>Zeit zum Auftanken</h3><p>Ruhetage unterbrechen deinen Streak nicht. Genieße deinen freien Kopf.</p></div>}
    <div className="plan-tip"><Icon name="spark" size={20}/><div><strong>Gut verteilt!</strong><p>Dein Plan lässt genug Puffer vor der Statistik-Klausur.</p></div></div>
  </section>
}

function SubjectsView({customSubjects,onAction}:{customSubjects:typeof exams;onAction:(title:string)=>void}) {
  const allExams=[...exams,...customSubjects]
  const [selected, setSelected] = useState(0)
  const details = [
    {tasks:"8 von 12", time:"9 Std. 20 Min.", next:"Hypothesentests", bg:"purple"},
    {tasks:"5 von 14", time:"6 Std. 45 Min.", next:"Marktformen", bg:"orange"},
    {tasks:"4 von 11", time:"4 Std. 10 Min.", next:"Markenführung", bg:"teal"},
  ]
  const current = allExams[selected]
  const detail = details[selected] || {tasks:"0 von 0",time:"0 Min.",next:"Deine erste Lernaufgabe",bg:"teal"}
  return <section className="subpage subjects-page">
    <div className="subject-tabs">{allExams.map((e,i)=><button key={e.subject} className={`${e.color} ${selected===i?"selected":""}`} onClick={()=>setSelected(i)}><span>{e.subject.slice(0,2)}</span>{e.subject}</button>)}</div>
    <article className={`subject-hero ${current.color}`}>
      <div className="subject-hero-top"><span>NÄCHSTER TERMIN</span><button onClick={()=>onAction("Aufgabe hinzufügen")} aria-label="Aufgabe zum Fach hinzufügen">•••</button></div>
      <h2>{current.subject}</h2>
      <p>{current.detail}</p>
      <div className="countdown"><strong>{current.day}</strong><div><span>{current.month === "JUN" ? "Juni" : "Juli"}</span><small>noch {selected === 0 ? "7" : selected === 1 ? "14" : "21"} Tage</small></div></div>
      <div className="hero-progress"><div><span>Lernfortschritt</span><strong>{current.progress}%</strong></div><i><b style={{width:`${current.progress}%`}}></b></i></div>
    </article>
    <div className="subject-stats"><div><Icon name="check" size={18}/><strong>{detail.tasks}</strong><span>Aufgaben</span></div><div><Icon name="clock" size={18}/><strong>{detail.time}</strong><span>Lernzeit</span></div></div>
    <div className="next-task">
      <div className={`subject-mark ${detail.bg}`}><Icon name="book"/></div>
      <div><span>ALS NÄCHSTES</span><h3>{detail.next}</h3><p>45 Min. · Heute um 09:00</p></div>
      <button onClick={()=>onAction("Aufgabe hinzufügen")} aria-label="Aufgabe öffnen"><Icon name="arrow" size={18}/></button>
    </div>
    <div className="subject-actions"><button onClick={()=>onAction("Aufgabe hinzufügen")}><Icon name="plus" size={18}/> Aufgabe</button><button onClick={()=>onAction("Neues Fach hinzufügen")}><Icon name="calendar" size={18}/> Termin</button></div>
    <button onClick={()=>onAction("Neues Fach hinzufügen")} className="all-subjects"><Icon name="plus" size={18}/> Neues Fach hinzufügen</button>
  </section>
}

function ProfileView({onOnboarding,profile}:{onOnboarding:()=>void;profile:Profile}) {
 const [editing,setEditing]=useState("")
 const [times,setTimes]=useState(()=>localStorage.getItem("studysync-times")||"Mo–Fr · 09:00–18:00 Uhr")
 const [rest,setRest]=useState(()=>localStorage.getItem("studysync-rest")||"Samstag und Sonntag")
 return <section className="subpage profile"><div className="large-avatar">LS</div><h2>Lea Schneider</h2><p>BWL · 4. Semester</p><div className="stat-row"><div><strong>7</strong><span>Tage Streak</span></div><div><strong>18</strong><span>Ziele erreicht</span></div><div><strong>24h</strong><span>gelernt</span></div></div>{[["Meine Lernzeiten",times],["Ruhetage",rest]].map(([title,value])=><article className="settings" key={title}><h3>{title}</h3><p>{value}</p><button aria-label={title+" bearbeiten"} onClick={()=>setEditing(title)}><Icon name="arrow" size={18}/></button></article>)}<button className="profile-onboarding" onClick={onOnboarding}><span className="feature-icon lavender"><Icon name="spark"/></span><span><strong>Dein persönliches Lernprofil</strong><small>{profile.goals.length?"Vorlieben und Lernrhythmus bearbeiten":"In 5 Schritten zu deinem passenden Lernplan"}</small></span><Icon name="arrow" size={18}/></button><p className="prototype-note">StudySync Konzeptprototyp · Alle Empfehlungen und Integrationen sind simuliert.</p>{editing&&<div className="dialog-overlay"><form className="entry-dialog" onSubmit={e=>{e.preventDefault();const value=new FormData(e.currentTarget).get("value") as string;if(editing==="Ruhetage"){setRest(value);localStorage.setItem("studysync-rest",value)}else{setTimes(value);localStorage.setItem("studysync-times",value)}setEditing("")}}><button type="button" className="dialog-close" aria-label="Schließen" onClick={()=>setEditing("")}>×</button><h2>{editing}</h2><label>Deine Verfügbarkeit<input name="value" required defaultValue={editing==="Ruhetage"?rest:times}/></label><button className="primary-button">Speichern</button></form></div>}</section>
}
function EntryDialog({title,onClose,onSubmit}:{title:string;onClose:()=>void;onSubmit:(d:Record<string,string>)=>void}) {
 const subjectOnly=title==="Neues Fach hinzufügen"
 return <div className="dialog-overlay" onClick={onClose}><form role="dialog" aria-modal="true" aria-label={title} className="entry-dialog" onClick={e=>e.stopPropagation()} onSubmit={e=>{e.preventDefault();onSubmit(Object.fromEntries(new FormData(e.currentTarget)) as Record<string,string>)}}><button type="button" className="dialog-close" onClick={onClose} aria-label="Schließen">×</button><span className="feature-icon mint"><Icon name={subjectOnly?"book":"plus"}/></span><h2>{title}</h2><label>Fach<input autoFocus name="subject" placeholder="z. B. Statistik" required/></label>{subjectOnly?<><label>Prüfungsdatum<input type="date" name="date" required/></label><label>Schwierigkeit<select name="difficulty"><option>mittel</option><option>schwierig</option><option>einfach</option></select></label></>:<><label>Was möchtest du lernen?<input name="title" placeholder="z. B. Übungsblatt 9 lösen" required/></label><div className="exam-field-row"><label>Uhrzeit<input type="time" name="time" defaultValue="17:00" required/></label><label>Dauer in Minuten<input type="number" min="5" max="240" name="duration" defaultValue="25" required/></label></div></>}<button className="primary-button">Speichern <Icon name="check" size={18}/></button></form></div>
}
