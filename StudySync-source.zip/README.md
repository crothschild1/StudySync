# StudySync

React + TypeScript recreation of the supplied StudySync dashboard, with the five-screen German learning-profile onboarding available under **Profil → Dein persönliches Lernprofil**.

## Run locally

```sh
npm install
npm run dev
```

Create a production build with `npm run build`. Vite serves the app at http://127.0.0.1:5173.

## Deliverables

- Figma design: https://www.figma.com/design/69D5q8x9wWsLqShBE9ZxKO
- Dashboard prototype: https://www.figma.com/proto/69D5q8x9wWsLqShBE9ZxKO?node-id=6-2662&starting-point-node-id=6%3A2662
- Onboarding prototype: https://www.figma.com/proto/69D5q8x9wWsLqShBE9ZxKO?node-id=6-3035&starting-point-node-id=6%3A3035
- Web prototype: https://studysync-lernplan.dearfawn69.chatgpt.site
- Direct onboarding entry: add `?onboarding` to the web URL.

## Demo behavior

The dashboard includes session completion, adding sessions, a weekly plan, subject views, profile settings, and a simulated Pro replanning flow. The five-screen onboarding retains preferences in local browser storage, supports editable exams and a time slider, and creates recommendations from study time, focus duration, preferences, challenges, and exam urgency. Its final screen demonstrates redistributing a missed session.

Everything runs in the browser. Recommendations, paid features, calendar integrations, progress data and AI behavior are simulated; no subscription is created. There are no fixed visual/auditory/kinesthetic learning types.

The Figma file contains editable native layers and clickable component states. Free-form data entry and dynamic recommendation calculations are implemented in React; Figma uses example content, and exam editing links to the web prototype. The Figma Starter plan does not support variable-based prototype actions.

## Visual reference

The screenshot dashboard intentionally keeps the example June schedule and Lea Schneider profile. The onboarding uses October 24, 2026 as the presentation reference date for its exam examples.
